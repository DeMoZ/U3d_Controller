﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
//[RequireComponent(typeof(CharacterController))]
//[RequireComponent(typeof(Rigidbody))]
public class Camera_ : MonoBehaviour
{
    //public string clampObjName = "";
    [Tooltip("Camera will work as Third person Camera")]
    public bool ThirdPersonCamera = true;

    [Tooltip("Transform of the object to follow")]
    public Transform bodyTransform;
    private Transform camTransform;
    private Vector3 bodyPos;

    [Tooltip("Camera will keep object not in the center of the screen")]
    [SerializeField] private Vector2 bodyOffset = new Vector2(2, 2);
    //private CharacterController controller;


    private Vector3 joyLook = new Vector3();

    [Header("Zoom properties")]
    [Tooltip("Start zoom value")]
    [SerializeField] private float zoomDefault = -4f;
    private float zoomActual;
    [Range(0, 10)]
    [SerializeField] private float zoomStep = 1;
    private float zoomClamped;

    private float joyZoom = 0;


    [Tooltip("Minimum close to body value")]
    [SerializeField] private float zoomMin = -0.3f;
    [Tooltip("Maximum far from body value")]
    [SerializeField] private float zoomMax = -10f;


    [Space]
    [Range(0, 89.9f)]
    [Tooltip("Maximum angle look Down")]
    [SerializeField] private float xClampMax = 89.9f;
    [Range(-89.9f, 0)]
    [Tooltip("Minimum angle look Up")]
    [SerializeField] private float xClampMin = -89.9f;

    [Tooltip("Test value if obstacle between camera and body")]
    private bool hitClamp;

    // private Vector3 moveJoy = new Vector3();

    // > OLD******************************************OLD
    private Vector3 camSpeed = new Vector3(70, 20, 5);
    [Header("Old Experience section")]
    private Vector3 directionMoveRelative = new Vector3();
    private Vector3 directionLookRelative = new Vector3();

    private float CamZoomStep = 5;
    private float zoom;
    private float distance;
    private Vector3 bodyOffsetOld = new Vector3(0, 2, 2); // camera offset behind the player
    private readonly float zoomPrevious;
    private Vector3 _transformPosition; // Camera Position for calculation before actual apply to camera

    private readonly CameraZoomState cameraZoom = CameraZoomState.Zoom3;
    public enum CameraZoomState
    {
        Zoom1 = 1,      //      |       camera position with different offset value
        Zoom2,          //      |
        Zoom3,          //       \
        Zoom4,          //        \
        Zoom5           //         \
    }

    [Header("Camera Self Relative props")]
    private float defaultSelfRelativeHeight = 2;
    private float camSpeedSelfRelative = 10;

    private CameraMovingState camMoveState;
    public enum CameraMovingState
    {
        movePlayerRelative,
        moveSelfRelative
    }

    private bool smoothZoom = true;
    private bool clampCollisions = true;
    [Tooltip("if zoom clamped, zooming will not accumulate")]
    private bool actualZoom = true;

    //private bool hitClamp;
    private float camZValue;
    private float range = 10000;    // to avoid tremling at 0 distance when zooming
    private float rangesum;
    // < OLD ********************************************OLD
    private void Start()
    {
        camTransform = transform;
        //controller = GetComponent<CharacterController>();
        zoomActual = zoomDefault;
    }
    void Update()
    {
        if (ThirdPersonCamera)
            TakeValuesFromControl();
    }
    void LateUpdate()
    {
        if (ThirdPersonCamera)
            CameraMoveUpdate();
    }
    private void TakeValuesFromControl()
    {
        // Get looking joy
        joyLook = ControllerHub.GetControllerTouch("TouchArea").GetAxis();

        // Get zoom. Need to also get zoom from on screen controls
        joyZoom = ControllerHub.GetControllerTouch("TouchArea").GetMouseWheel();
        if (joyZoom > 0) joyZoom += zoomStep;
        if (joyZoom < 0) joyZoom -= zoomStep;
        zoomActual += joyZoom;

        zoomActual = Mathf.Clamp(zoomActual, zoomMax, zoomMin);
        // <


    }
    //public void SetZoom(float zm)
    //{
    //    zoomActual += zm;
    //}

    void CameraMoveUpdate()
    {
        if (bodyTransform == null) return;
        bodyPos = bodyTransform.position;

        float xEuler = Clamp_xEuler(camTransform.eulerAngles.x + joyLook.y);

        Quaternion rotation = Quaternion.Euler(xEuler, camTransform.eulerAngles.y + joyLook.x, 0f);

 //       zoomClamped = Clamp_Collision(bodyPos);

//        Vector3 position = rotation * new Vector3(bodyOffset.x, bodyOffset.y, zoomClamped) + bodyPos;//

        

        Vector3 position = rotation * new Vector3(bodyOffset.x, bodyOffset.y, zoomActual) + bodyPos;
        position = PositionClamped(bodyPos,position);

        camTransform.rotation = rotation;
        camTransform.position = position;
    }

    private Vector3 PositionClamped(Vector3 _bodyPos,Vector3 _position)
    {
        float _distance = Vector3.Distance(_bodyPos, _position);
        Vector3 _direction = (_position - _bodyPos);
        Ray _ray = new Ray(_bodyPos, _direction);
        RaycastHit _hit;

        if (Physics.Raycast(_ray, out _hit, _distance))
        {
            if ((_hit.distance < _distance))// && _hit.transform.name != gameObject.name)
            {
                _distance = _hit.distance;
               // clampObjName = "!!! " + _hit.transform.name + " !!!";

                return _hit.point;
            }
            else
            {
               // clampObjName = _hit.transform.name;
                Debug.DrawRay(_bodyPos, camTransform.position - _bodyPos, Color.blue);
            }
        }

        return _position;
    }

    //private float Clamp_Collision(Vector3 _bodyPos)
    //{
    //    float _distance = Mathf.Abs(zoomActual) + 1;
    //    //float sign = Mathf.Sign(zoomActual);
    //    Vector3 direction = camTransform.position - _bodyPos;
    //    Ray _ray = new Ray(_bodyPos, direction);
    //    RaycastHit _hit;
    //    clampObjName = "";
    //    Debug.DrawRay(_bodyPos, direction);
    //    // Debug.DrawRay(_ray);
    //    if (Physics.Raycast(_ray, out _hit, _distance))
    //    {
    //        if ((_hit.distance < _distance) && _hit.transform.name != gameObject.name)
    //        {
    //            _distance = _hit.distance;
    //            clampObjName = "!!! " + _hit.transform.name + " !!!";
    //        }
    //        else
    //        {
    //            clampObjName = _hit.transform.name;
    //            Debug.DrawRay(_bodyPos, camTransform.position - _bodyPos, Color.blue);
    //        }
    //    }
        
    //    //return (_distance * Mathf.Sign(zoomActual));
    //    return -_distance;
    //}

    float Clamp_xEuler(float angle)
    {
        // иногда проскакивает значение угла ниже 0 и выше 360. это правлю
        if (angle < 0) angle += 360;
        if (angle > 360) angle -= 360;
        // Debug.Log("angle<360 = " + angle);
        // запретить камере быть ниже  360+minimumY (минимум должен быть отрицательным)
        // запретить камере быть выше maximumY
        if (angle > 180)
            return Mathf.Clamp(angle, 360 + xClampMin, 360);
        else
            return Mathf.Clamp(angle, xClampMin, xClampMax);
    }
    //--------------------------------------------------------------------------------------------------------------

    private void TakeValuesFromControlsOldExperience()
    {
        // Get looking joy
        joyLook = ControllerHub.GetControllerTouch("TouchArea").GetAxis();
        joyLook.z = ControllerHub.GetControllerTouch("TouchArea").GetMouseWheel();

        // Get moving joy
        //moveJoy = ControllerHub.GetControllerJoy("JoyArea").GetAxis();

        switch (camMoveState)
        {
            case CameraMovingState.moveSelfRelative:    // moving self relative by move joy, looking by look joy (FPS like)
                                                        // controller.enabled = true;
                directionMoveRelative = ControllerHub.GetControllerTouch("TouchArea").GetAxisRelated(camTransform);
                break;
            case CameraMovingState.movePlayerRelative:  // moving around player by look joy (TPS like)
                if (bodyTransform == null) return;
                //controller.enabled = false;
                bodyPos = bodyTransform.position;
                directionLookRelative = ControllerHub.GetControllerTouch("TouchArea").GetAxisRelated(camTransform);
                break;
        }
    }

    private void CameraMoveUpdateOldExperience()
    {
        switch (camMoveState)
        {
            /*
            case CameraMovingState.moveSelfRelative:    // moving self relative by move joy, looking by look joy (FPS like)
                CameraSelfRelativeMovement(directionMoveRelative);
                CameraSelfRelativeRotation(joyLook);

                break;
                */
            case CameraMovingState.movePlayerRelative:  // moving around player by look joy (TPS like)
                //!!! base                  CameraPlayerRelativeMovementBase(lookJoy, bodyPos);
                Vector3 _bodyPosOffseted = new Vector3(bodyPos.x, bodyPos.y + bodyOffset.y, bodyPos.z);
                CameraPlayerRelativeRotationOldExperience(camTransform, _bodyPosOffseted, camTransform.eulerAngles, joyLook);

                break;
        }
    }

    /*private void CameraSelfRelativeRotation(Vector2 direction)
    {
        camTransform.localEulerAngles = new Vector3(camTransform.localEulerAngles.x + direction.y, camTransform.localEulerAngles.y + direction.x
            , camTransform.localEulerAngles.z);
    }
    */
    /*private void CameraSelfRelativeMovement(Vector3 moveDirection)
    {
        // find y point above ground to move camera to that height
        Ray rayCollision = new Ray(camTransform.position, Vector3.down);
        RaycastHit hitCollision;
        if (Physics.Raycast(rayCollision, out hitCollision))//,layerMask
        {
            moveDirection.y += (defaultSelfRelativeHeight - hitCollision.distance);
        }
        else
        {
            moveDirection.y -= defaultSelfRelativeHeight;
        }

        //controller.Move(moveDirection * Time.fixedDeltaTime * camSpeedSelfRelative);
    }
    */
    // public float _distance;
    private void CameraPlayerRelativeRotationOldExperience(Transform _camT, Vector3 _bodyPos, Vector3 _camEuler, Vector3 _joy)
    {
        Quaternion rotation = Quaternion.Euler(_camEuler.x + _joy.y, _camEuler.y + _joy.x, 0.0f);
        float _distance;
        _distance = GetDistance(_camT.forward, _bodyPos, _joy.z, smoothZoom);

        _distance = (clampCollisions) ? CollisionClampOldExperience(_camT.forward, _bodyPos, _distance) : _distance;
        _distance = (actualZoom) ? ActualZoom(_bodyPos, _distance, _joy.z) : _distance;

        Vector3 position = rotation * new Vector3(0, 0, _distance) + _bodyPos;

        camTransform.rotation = rotation;
        camTransform.position = position;
    }

    float GetDistance(Vector3 _direction, Vector3 _bodyPos, float _zoom, bool _smoothZ)
    {
        Ray ray = new Ray(_bodyPos, _direction);
        Vector3 point = ray.GetPoint(range);
        distance = Vector3.Distance(point, camTransform.position);

        zoom += _zoom * CamZoomStep;
        rangesum = range - zoom;

        if (_smoothZ)
        {
            float res = Mathf.Lerp(distance, rangesum, Time.fixedDeltaTime * camSpeed.z);
            return range - res;
        }
        else
            return range - rangesum;
    }

    float CollisionClampOldExperience(Vector3 _direction, Vector3 _bodyPos, float _distance)
    {
        Ray _rayPoint = new Ray(_bodyPos, _direction);
        Vector3 _point = _rayPoint.GetPoint(range);
        Ray _ray = new Ray(_bodyPos, camTransform.position - _bodyPos);
        RaycastHit _hit;
        hitClamp = false;

        if (Physics.Raycast(_ray, out _hit, Mathf.Abs(_distance)))
        {
            if (_hit.distance < Mathf.Abs(_distance))
            {
                hitClamp = true;
                //if (_distance < 0)
                //{                    
                _distance = (Vector3.Distance(_point, _hit.point) >= range)
                        ? -_hit.distance
                        : _hit.distance;
                //}
                //else
                //{                    
                //    _distance = (Vector3.Distance(_point, _hit.point) >= range)
                //            ? -_hit.distance
                //            : _hit.distance;
                //}

            }

            //if (_hit.distance < Mathf.Abs(_distance))
            //{
            //    hitClamp = true;
            //    _distance = (Vector3.Distance(_point, _hit.point) >= range)
            //            ? -_hit.distance
            //            : _hit.distance;
            //}
        }
        return _distance;
    }

    float ActualZoom(Vector3 _bodyPos, float _distance, float _zoom)
    {
        if (hitClamp & _zoom > 0)
        {
            _distance = Mathf.Sign(_distance) * Vector3.Distance(camTransform.position, _bodyPos);
            zoom = _distance;
        }
        return _distance;
    }

    // !!! check for angle clamp !!! ------------------------------- some old experience
    //private float swipeDeltaYClamped;
    //private float minimumY = -85;
    //private float maximumY = 85;
    //private float camOffsetZCurrent = 3;
    //private float camOffsetZCurrentCollisioned = 0;
    //private Quaternion _rotation = new Quaternion();
    //private Vector3 bodyOffset = new Vector3(0, 2, 2);
    ////private Vector3 nextPos = new Vector3();
    ////    private Vector3 bodyPosOffseted = new Vector3();

    //void Rotation(Vector3 _swipeDelta, Vector3 _bodyPos)
    //{
    //    swipeDeltaYClamped = ClampAngle(_swipeDelta.y + _transform.eulerAngles.x, minimumY, maximumY);
    //    _rotation = Quaternion.Euler(swipeDeltaYClamped, _transform.eulerAngles.y + _swipeDelta.x, 0);
    //    //camOffsetZCurrent = camOffsetZCurrent + _mouseScroll * _camScrollStep;
    //    camOffsetZCurrent = Mathf.Clamp(camOffsetZCurrent, bodyOffset.z * 2, -bodyOffset.z * 2);

    //    //!!! bodyPosOffseted = new Vector3(_bodyPos.x, _bodyPos.y + bodyOffset.y, _bodyPos.z);

    //    camOffsetZCurrentCollisioned = camOffsetZCurrent;
    //    Vector3 cameraColliderPoint = _transform.TransformPoint(new Vector3(0, 0, -1));
    //    //!!! camOffsetZCurrentCollisioned = collision(cameraColliderPoint, bodyPosOffseted, camOffsetZCurrent, Vector3.Distance(cameraColliderPoint, bodyPosOffseted));
    //    //!!! Vector3 position = rotation * new Vector3(0, 0, camOffsetZCurrentCollisioned) + bodyPosOffseted;
    //    //!!!_transform.rotation = _rotation;
    //    //!!!_transform.position = position;
    //}

    //----------------------------------- collisions and clamps

    float ClampAngle(float angle, float min, float max)
    {
        // иногда проскакивает значение угла ниже 0 и выше 360. это правлю
        if (angle < 0) angle += 360;
        if (angle > 360) angle -= 360;
        // Debug.Log("angle<360 = " + angle);
        // запретить камере быть ниже  360+minimumY (минимум должен быть отрицательным)
        // запретить камере быть выше maximumY
        if (angle > 180)
            return Mathf.Clamp(angle, 360 + min, 360);
        else
            return Mathf.Clamp(angle, min, max);
    }

    //-----------------------------------base . first attemt that works
    private void CameraPlayerRelativeMovementBase(Vector3 moveDirection, Vector3 _bodyPos)
    {
        //Transform angle in degree in quaternion form used by Unity for rotation.
        Quaternion rotation = Quaternion.Euler(camTransform.eulerAngles.x + moveDirection.y, camTransform.eulerAngles.y + moveDirection.x, 0.0f);

        //The new position is the target position + the distance vector of the camera
        //rotated at the specified angle.
        Vector3 position = rotation * new Vector3(0, 0, -2) + _bodyPos;

        //Update the rotation and position of the camera.
        camTransform.rotation = rotation;
        camTransform.position = position;
    }


}
